package socket.proxy;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import socket.proxy.HttpParser.HttpHeader;

public class HttpHandler implements Runnable {
    // 客户端
    private Socket clientSocket;
    private InputStream clientInputStream;
    private OutputStream clientOutputStream;
    private final byte[] clientBytes;
    // 服务器端
    private Socket serverSocket;
    private InputStream serverInputStream;
    private OutputStream serverOutputStream;
    private final byte[] serverBytes;

    private boolean isNextRequest = true;// 正在加载httpHeader
    private boolean print = true;

    public HttpHandler(Socket client) {
        this.clientSocket = client;
        clientBytes = new byte[1024];
        serverBytes = new byte[1024];
    }

    @Override
    public void run() {
        // 转发给服务端
        sendToServer();

        // 转发给客户端
        sendToClient();

        // 关闭连接
        closeConnection();
    }

    /**
     * 创建连接
     *
     * @param c
     */
    private void createConnection(int c) {
        try {
            HttpHeader header = new HttpParser(clientBytes, c).parseHttpHeader(HttpHeader.CLIENT);
            if (header.host != null) {
                if (header.host.indexOf("netstudy") > 0) {
                    print = true;
                }

                serverSocket = new Socket(header.host, 80);
                serverOutputStream = serverSocket.getOutputStream();
                serverInputStream = serverSocket.getInputStream();
            }
        }
        catch (IOException e) {
            // e.printStackTrace();
            closeConnection();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 转发给服务端
     */
    private void sendToServer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    clientInputStream = clientSocket.getInputStream();
                    clientOutputStream = clientSocket.getOutputStream();

                    int c = 0;
                    while ((c = clientInputStream.read(clientBytes, 0, clientBytes.length)) > 0) {
                        // 发送信息
                        if (print) {
                            System.out.println(new String(clientBytes, 0, c, "utf-8"));
                        }

                        // 创建连接
                        if (serverSocket == null) {
                            createConnection(c);
                        }

                        if (serverOutputStream != null) {
                            serverOutputStream.write(clientBytes, 0, c);
                        }
                    }
                }
                catch (IOException e) {
                    // e.printStackTrace();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                closeConnection();
            }
        }).start();
    }

    /**
     * 转发给客户端
     */
    private void sendToClient() {
        HttpParser httpParser = new HttpParser();
        try {
            // 等待基本信息初始化
            while (serverInputStream == null) {
                Thread.sleep(5000);
            }

            // 接收并转发数据
            int c = 0;
            while ((c = serverInputStream.read(serverBytes, 0, serverBytes.length)) > 0) {
                httpParser.setBytes(serverBytes);
                httpParser.setC(c);

                // httpParser.saveFile();

                // 服务器校验
                if (isNextRequest && !httpParser.isServerVerify()) {
                    closeConnection();
                    return;
                }

                // 本次http访问结束
                if (httpParser.isHttpEnd()) {
                    isNextRequest = true;
                }

                // 发送信息
                System.out.println(new String(serverBytes, 0, c, "utf-8"));
                clientOutputStream.write(serverBytes, 0, c);

                if (serverSocket == null) {
                    return;
                }
            }
        }
        catch (IOException e) {
            // e.printStackTrace();
        }
        catch (InterruptedException e) {
            // e.printStackTrace();
        }

        // GzipParser gzipParser = new GzipParser(httpParser.getPath());
        // gzipParser.createGzip();
        // gzipParser.printGzip();

        closeConnection();
    }

    /**
     * 关闭连接
     */
    private void closeConnection() {
        if (serverSocket == null) {
            return;
        }

        try {
            serverSocket.close();
            serverSocket = null;
        }
        catch (IOException e) {
            e.printStackTrace();
            serverSocket = null;
        }

        try {
            clientSocket.close();
            clientSocket = null;
        }
        catch (IOException e) {
            e.printStackTrace();
            clientSocket = null;
        }
    }
}
