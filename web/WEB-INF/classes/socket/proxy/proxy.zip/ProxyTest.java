package socket.proxy;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;
import java.util.Scanner;

public class ProxyTest {
    public static void main(String[] args) throws IOException {
        Properties prop = System.getProperties();
        prop.setProperty("http.proxyHost", "localhost");
        prop.setProperty("http.proxyPort", "8082");

        URL url = new URL("http://yflb.kehou.com/mobileConfig.htm");
        // URL url = new URL("http://m.yflb.kehou.com/login.htm");
        // URL url = new URL("http://www.baidu.com");
        URLConnection conn = url.openConnection();
        // conn.setRequestProperty("netstudy", "1");
        Scanner scan = new Scanner(conn.getInputStream());
        // 读取远程主机的内容
        while (scan.hasNextLine()) {
            System.out.println(scan.nextLine());
        }
        scan.close();
    }
}
