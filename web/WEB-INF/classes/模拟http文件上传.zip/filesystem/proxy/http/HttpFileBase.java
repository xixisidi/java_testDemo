/* 
 * @(#)HttpFileSystem.java    Created on 2015-4-30
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import net.zdsoft.keel.util.SecurityUtils;
import net.zdsoft.keel.util.URLUtils;
import net.zdsoft.netstudy.common.config.NetstudyConfig;
import net.zdsoft.netstudy.common.constant.Constants;
import net.zdsoft.netstudy.common.enums.HttpFileEnum;

/**
 * 文件服务 --base
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-4-30 下午4:28:24 $
 */
public class HttpFileBase {
    Logger log = Logger.getLogger(HttpFileBase.class);

    // 常量
    protected static final String UTF8 = "UTF-8";
    protected static final String METHOD_HEAD = "HEAD";
    protected static final String METHOD_GET = "GET";
    protected static final String METHOD_PUT = "PUT";
    protected static final String METHOD_POST = "POST";
    protected static final String METHOD_DELETE = "DELETE";
    protected static final String CONTENT_LENGTH = "Content-Length";
    protected static final int TIME_OUT = 30 * 1000;

    // 访问地址
    protected String apiUrl;

    /**
     * url连接
     * 
     * @param params
     * @return
     * @return
     */
    public <T> T HttpAction(String uri, String method, HttpResult<T> result) throws IOException {
        HttpURLConnection conn = null;
        InputStream is = null;

        try {
            // 创建连接
            URL url = new URL(uri);
            // Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 8888));
            // conn = (HttpURLConnection) url.openConnection(proxy);
            conn = (HttpURLConnection) url.openConnection();

            // 设置必要参数
            conn.setConnectTimeout(TIME_OUT);
            conn.setRequestMethod(method);
            conn.setUseCaches(false);
            conn.setDoOutput(true);

            // 创建链接
            conn.connect();

            // 获取文件内容
            return result.result(conn);
        }
        catch (IOException e) {
            log.error(e);
            return null;
        }
        finally {
            try {
                if (is != null) {
                    is.close();
                    is = null;
                }
            }
            catch (IOException e) {
                log.error(e);
            }

            // 关闭连接
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }
        }
    }

    /**
     * 获得连接请求的返回信息
     * 
     * @param conn
     * 
     * @return 字符串
     */
    protected String getConnectionText(HttpURLConnection conn) throws IOException {
        StringBuilder text = new StringBuilder();

        InputStream is = null;
        InputStreamReader sr = null;
        BufferedReader br = null;
        int code = conn.getResponseCode();
        try {
            is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();

            sr = new InputStreamReader(is);
            br = new BufferedReader(sr);

            char[] chars = new char[4096];
            int length = 0;

            while ((length = br.read(chars)) != -1) {
                text.append(chars, 0, length);
            }
        }
        finally {
            if (br != null) {
                br.close();
                br = null;
            }
            if (sr != null) {
                sr.close();
                sr = null;
            }
            if (is != null) {
                is.close();
                is = null;
            }
        }

        return text.toString();
    }

    /**
     * 格式化url
     * 
     * @param path
     *            访问地址
     * @param operate
     *            操作
     * @param toPath
     *            转移地址的时候用
     * @return
     * @throws UnsupportedEncodingException
     */
    protected String formatUrl(String path, HttpFileEnum operate, String toPath) throws UnsupportedEncodingException {
        List<String> paramNames = new ArrayList<String>();
        List<Object> paramValues = new ArrayList<Object>();
        if (StringUtils.isNotBlank(path)) {
            paramNames.add("path");
            paramValues.add(URLEncoder.encode(path, "utf-8"));
        }
        if (operate != null) {
            paramNames.add("operate");
            paramValues.add(operate.getValue());
        }
        if (StringUtils.isNotBlank(toPath)) {
            paramNames.add("toPath");
            paramValues.add(URLEncoder.encode(toPath, "utf-8"));
        }

        // 身份验证
        if (operate == HttpFileEnum.DEL || operate == HttpFileEnum.MOVE || operate == HttpFileEnum.COPY) {
            paramNames.add("signature");
            paramValues.add(createSignature(path));
        }

        // 返回跳转地址
        return URLUtils.addQueryString(getApiUrl(), paramNames.toArray(new String[] {}), paramValues.toArray());
    }

    /**
     * 格式化路径
     * 
     * @param path
     * @return
     */
    protected String formatPath(String path) {
        if (StringUtils.isNotBlank(path)) {
            // 去除前后的空格
            path = path.trim();

            // 确保路径以"/"开头
            if (!path.startsWith(Constants.SEPERATOR)) {
                return Constants.SEPERATOR + path;
            }
        }

        return path;
    }

    /**
     * 编码
     * 
     * @param message
     * @return
     * @throws UnsupportedEncodingException
     */
    public String encode(String message) throws UnsupportedEncodingException {
        return URLEncoder.encode(message, UTF8);
    }

    /**
     * 创建签名
     * 
     * @return
     */
    public String createSignature(String path) {
        return SecurityUtils.encodeByMD5(path + Constants.NETSTUDY_COMMON_TOKEN);
    }

    protected String getApiUrl() {
        if (apiUrl == null) {
            apiUrl = NetstudyConfig.getParam(Constants.DOMAIN_STORAGE) + "/upload/api.htm";
        }
        return apiUrl;
    }
}
