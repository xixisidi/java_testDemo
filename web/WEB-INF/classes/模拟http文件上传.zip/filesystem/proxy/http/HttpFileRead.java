/* 
 * @(#)HttpFileSystem.java    Created on 2015-4-30
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy.http;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;

import com.opensymphony.util.GUID;

import net.zdsoft.netstudy.common.constant.Constants;
import net.zdsoft.netstudy.common.enums.HttpFileEnum;
import net.zdsoft.netstudy.common.utils.OSUtil;

/**
 * 文件服务-文件下载
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-4-30 下午4:28:24 $
 */
public class HttpFileRead extends HttpFileWrite {

    /**
     * 将文件从文件服务器拷贝到本地
     * 
     * @return
     * @throws IOException
     * @throws Exception
     */
    public Boolean copyFileToLocal(String filePath, String localFilePath) throws IOException {
        try {
            final File file = new File(localFilePath);
            Boolean result = HttpAction(formatUrl(filePath, HttpFileEnum.DOWNLOAD, null), METHOD_GET,
                    new HttpResult<Boolean>() {
                        @Override
                        public Boolean result(HttpURLConnection conn) throws IOException {
                            OutputStream os = null;
                            InputStream is = null;
                            try {
                                os = new FileOutputStream(file);
                                byte[] data = new byte[4096];
                                int temp = 0;

                                is = conn.getInputStream();

                                while ((temp = is.read(data)) != -1) {
                                    os.write(data, 0, temp);
                                }
                            }
                            finally {
                                try {
                                    if (os != null) {
                                        os.close();
                                        os = null;
                                    }
                                    if (is != null) {
                                        is.close();
                                        is = null;
                                    }
                                }
                                catch (IOException e) {
                                    log.debug(e.getMessage());
                                }
                            }
                            return true;
                        }
                    });
            if (result == null) {
                return false;
            }

            return result;
        }
        catch (Exception e) {
            return false;
        }
    }

    /**
     * 获取文件服务器文件流
     * 
     * @param filePath
     * @return
     */
    public InputStream getFileAsStream(String filePath) {
        try {
            return HttpAction(formatUrl(filePath, HttpFileEnum.DOWNLOAD, null), METHOD_GET,
                    new HttpResult<InputStream>() {
                        @Override
                        public InputStream result(HttpURLConnection conn) throws IOException {
                            InputStream is = null;
                            FileOutputStream fo = null;

                            try {
                                String tempPath = OSUtil.getTempDir() + Constants.SEPERATOR + GUID.generateGUID()
                                        + ".temp";
                                is = conn.getInputStream();
                                fo = new FileOutputStream(tempPath);
                                byte[] data = new byte[4096];
                                int temp = 0;
                                while ((temp = is.read(data)) != -1) {
                                    fo.write(data, 0, temp);
                                }

                                return new FileInputStream(tempPath);
                            }
                            finally {
                                try {
                                    if (is != null) {
                                        is.close();
                                    }

                                    if (fo != null) {
                                        fo.close();
                                    }
                                }
                                catch (IOException e) {
                                    log.error(e);
                                }
                            }
                        }
                    });
        }
        catch (Exception e) {
            log.debug(e.getMessage());
            return null;
        }
    }

    /**
     * 读取文件服务器文本文件内容
     * 
     * @param filePath
     * @return
     * @throws Exception
     */
    public String getFileAsString(String filePath) {
        try {
            return HttpAction(formatUrl(filePath, HttpFileEnum.DOWNLOAD, null), METHOD_GET, new HttpResult<String>() {
                @Override
                public String result(HttpURLConnection conn) throws IOException {
                    if (conn.getResponseCode() >= 400) {
                        log.error(getConnectionText(conn));
                        return null;
                    }
                    return getConnectionText(conn);
                }
            });
        }
        catch (Exception e) {
            return null;
        }
    }
}
