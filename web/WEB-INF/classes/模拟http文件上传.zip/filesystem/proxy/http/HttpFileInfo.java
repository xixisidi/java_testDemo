/* 
 * @(#)HttpFileSystem.java    Created on 2015-4-30
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy.http;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSONObject;

import net.zdsoft.netstudy.common.enums.HttpFileEnum;

/**
 * 文件服务-文件基本信息和文件操作
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-4-30 下午4:28:24 $
 */
public class HttpFileInfo extends HttpFileRead {

    /**
     * 获取文件列表
     * 
     * @param path
     * @throws IOException
     */
    public String[] getFileList(String path) throws IOException {
        return HttpAction(formatUrl(path, HttpFileEnum.LIST, null), METHOD_GET, new HttpResult<String[]>() {
            @Override
            public String[] result(HttpURLConnection conn) throws IOException {
                int code = conn.getResponseCode();
                if (code >= 400) {
                    log.error("文件访问失败：" + code);
                    return null;
                }
                JSONObject json = JSONObject.parseObject(getConnectionText(conn));
                if (json.get("list") == null) {
                    return null;
                }
                return json.getJSONArray("list").toArray(new String[] {});
            }
        });
    }

    /**
     * 操作文件
     * 
     * @param path
     * @param operate
     * @return
     * @throws IOException
     */
    public String operateFile(String path, HttpFileEnum operate, String topath) throws IOException {
        return HttpAction(formatUrl(path, operate, topath), METHOD_HEAD, new HttpResult<String>() {
            @Override
            public String result(HttpURLConnection conn) throws IOException {
                int code = conn.getResponseCode();
                if (code >= 400) {
                    log.error("文件访问失败：" + code);
                    return null;
                }
                else {
                    return conn.getHeaderField(HttpFileEnum.RESULT.toString());
                }
            }
        });
    }

    /**
     * 获取文件大小
     * 
     * @param path
     * @return
     * @return
     */
    public Long getFileLength(String path) throws IOException {
        String result = operateFile(formatPath(path), HttpFileEnum.LENGTH, null);
        if (StringUtils.isBlank(result)) {
            return null;
        }
        return Long.parseLong(result);
    }

    /**
     * 文件是否存在
     * 
     * @param path
     * @param type
     *            文件|文件夹
     * @return
     * @throws IOException
     */
    public Boolean getFileExist(String path, HttpFileEnum type) throws IOException {
        String result = operateFile(formatPath(path), type, null);
        if (StringUtils.isBlank(result)) {
            return false;
        }
        return Boolean.parseBoolean(result);
    }

    /**
     * 获取文件上传日期
     * 
     * @param path
     * @return
     * @throws IOException
     */
    public Date getFileDate(String path) throws IOException {
        String result = operateFile(formatPath(path), HttpFileEnum.DATE, null);
        if (StringUtils.isBlank(result)) {
            return null;
        }
        return new Date(Long.parseLong(result));
    }

    /**
     * 创建文件夹
     * 
     * @param path
     * @return
     * @throws IOException
     */
    public boolean makeDir(String path) throws IOException {
        String result = operateFile(formatPath(path), HttpFileEnum.MK_DIR, null);
        if (StringUtils.isBlank(result)) {
            return false;
        }
        return Boolean.parseBoolean(result);
    }

    /**
     * 删除文件或文件夹
     * 
     * @param path
     * @return
     * @throws IOException
     */
    public boolean deleteFileOrDir(String path) throws IOException {
        String result = operateFile(formatPath(path), HttpFileEnum.DEL, null);
        if (StringUtils.isBlank(result)) {
            return false;
        }
        return Boolean.parseBoolean(result);
    }

    /**
     * 转移文件夹
     * 
     * @param src
     * @param desc
     * @return
     * @throws IOException
     */
    public boolean moveFile(String src, String desc) throws IOException {
        String result = operateFile(formatPath(src), HttpFileEnum.MOVE, formatPath(desc));
        if (StringUtils.isBlank(result)) {
            return false;
        }
        return Boolean.parseBoolean(result);
    }

    /**
     * 复制文件夹
     * 
     * @param src
     * @param desc
     * @return
     * @throws IOException
     */
    public boolean copyFile(String src, String desc) throws IOException {
        String result = operateFile(formatPath(src), HttpFileEnum.COPY, formatPath(desc));
        if (StringUtils.isBlank(result)) {
            return false;
        }
        return Boolean.parseBoolean(result);
    }
}
