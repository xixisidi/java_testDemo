/* 
 * @(#)ConnectionOperate.java    Created on 2015-5-5
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy.http;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * 连接处理
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-5-5 下午3:12:56 $
 */
public interface HttpResult<T> {
    /**
     * 返回信息
     * 
     * @param is
     */
    public T result(HttpURLConnection conn) throws IOException;
}
