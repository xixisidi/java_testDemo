/* 
 * @(#)HttpFileSystem.java    Created on 2015-4-30
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy.http;

import java.io.IOException;

/**
 * 文件服务
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-4-30 下午4:28:24 $
 */
public class HttpFile extends HttpFileInfo {

    public static void main(String[] args) throws IOException {
        // HttpFileInfo read = new HttpFileInfo("http://cms.netstudy5.dev/upload/api.htm");
        // File file = new File("G://88.jpg");
        // read.writeFile("/dev/88.jpg", file);
        // System.out.println(read.makeDir("/1/1/1/1"));
        // System.out.println(read.getFileExist("/total/8.jpg"));
        // System.out.println(read.getFileLength("/total/8.jpg"));
        // System.out.println(read.getFileDate("/total/8.jpg"));
        // System.out.println(read.deleteFileOrDir("/total/"));
        // System.out.println(StringUtils.join(read.getFileList("/total/"), "\r\n"));
    }
}
