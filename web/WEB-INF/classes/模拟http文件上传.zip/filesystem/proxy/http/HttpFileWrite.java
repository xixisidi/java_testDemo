/* 
 * @(#)HttpFileSystem.java    Created on 2015-4-30
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy.http;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

import net.zdsoft.netstudy.common.cache.CacheCall.CacheObjectParam;
import net.zdsoft.netstudy.common.constant.DataTypeConstants;
import net.zdsoft.netstudy.common.enums.HttpFileEnum;
import net.zdsoft.netstudy.common.utils.CacheUtil;
import net.zdsoft.netstudy.common.utils.Util;

/**
 * 文件服务-写文件
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-4-30 下午4:28:24 $
 */
public class HttpFileWrite extends HttpFileBase {

    protected final String boundary = "------------cH2ei4Ij5cH2gL6KM7Ef1Ij5ei4gL6";

    /**
     * 上传文件
     * 
     * @param filePath
     * @param file
     * @return
     * @throws IOException
     */
    public boolean writeFile(String filePath, File file) throws IOException {
        FileInputStream is = new FileInputStream(file);
        return writeFile(filePath, is);
    }

    /**
     * 上传字符串
     * 
     * @param filePath
     * @param text
     * @return
     * @throws IOException
     */
    public boolean writeFile(String filePath, String text) throws IOException {
        ByteArrayInputStream is = new ByteArrayInputStream(text.getBytes());
        return writeFile(filePath, is);
    }

    /**
     * 上传流
     * 
     * @param filePath
     *            文件路径（包含文件名）
     * @param is
     *            待上传的文件流
     * @param auto
     *            是否自动创建父级目录(最多10级)
     * @param params
     *            额外参数
     * 
     * @return true or false
     * @throws IOException
     */
    public boolean writeFile(String filePath, InputStream is) throws IOException {
        OutputStream os = null;
        HttpURLConnection conn = null;

        String beforeFileContent = createBeforeFileContent(filePath);
        String afterFileContent = createAfterFileContent();
        try {
            // 获取链接
            URL url = new URL(getUploadUrl());
            // Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 8888));
            // conn = (HttpURLConnection) url.openConnection(proxy);
            conn = (HttpURLConnection) url.openConnection();

            // 设置必要参数
            conn.setConnectTimeout(TIME_OUT);
            conn.setRequestMethod(METHOD_POST);
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setRequestProperty("Accept", "*/*");

            // 创建链接
            conn.connect();

            os = conn.getOutputStream();
            byte[] data = null;

            // 文件上传前的内容
            data = beforeFileContent.getBytes();
            os.write(data, 0, data.length);

            // 文件上传
            data = new byte[4096];
            int temp = 0;
            while ((temp = is.read(data)) != -1) {
                os.write(data, 0, temp);
            }

            // 文件上传后的内容
            data = afterFileContent.getBytes();
            os.write(data, 0, data.length);
            os.flush();

            // 获取返回的信息
            log.debug(getConnectionText(conn));
            // 上传成功
            return true;

        }
        catch (IOException e) {
            log.error(e);
            // 上传失败
            return false;

        }
        finally {

            if (os != null) {
                os.close();
                os = null;
            }
            if (is != null) {
                is.close();
            }
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }
        }
    }

    /**
     * 文件前的内容
     * 
     * @return
     * @throws IOException
     */
    private String createBeforeFileContent(String path) throws IOException {
        // 获取文件名称
        int i = path.lastIndexOf("/");
        int j = path.lastIndexOf("\\");
        i = i > j ? i : j;
        String fileName = path.substring(i + 1);

        // =========================字符串提交_S=============================
        String policy = createPolicy(path);
        StringBuffer contentBuffer = new StringBuffer();
        contentBuffer.append("--" + boundary + "\r\n");
        contentBuffer.append("Content-Disposition: form-data; name=\"policy\"\r\n\r\n");
        contentBuffer.append(policy + "\r\n");
        // =========================字符串提交_E=============================

        // =========================文件提交_S=============================
        // 文件头信息
        contentBuffer.append("--" + boundary + "\r\n");
        contentBuffer
                .append("Content-Disposition: form-data; name=\"file\"; filename=\"" + encode(fileName) + "\"\r\n");
        contentBuffer.append("Content-Type:application/octet-stream\r\n");
        contentBuffer.append("\r\n");
        return contentBuffer.toString();
    }

    /**
     * 文件后的内容
     * 
     * @return
     */
    private String createAfterFileContent() {
        StringBuffer contentBuffer = new StringBuffer();
        contentBuffer.append("\r\n");
        // =========================文件提交_E=============================

        // 结尾
        contentBuffer.append("--" + boundary + "--" + "\r\n");
        contentBuffer.append("\r\n");
        return contentBuffer.toString();
    }

    /**
     * 创建policy
     * 
     * @throws IOException
     * @throws UnsupportedEncodingException
     */
    private String createPolicy(String path) throws UnsupportedEncodingException, IOException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("save-key", path);
        String policy = jsonObject.toJSONString();
        policy = (new sun.misc.BASE64Encoder()).encode(policy.getBytes());
        policy = policy.replaceAll("\\r\\n", "");// 去除换行符
        return policy;
    }

    /**
     * 获取文件上传的接口
     * 
     * @return
     * @throws Exception
     * @throws IOException
     */
    private String getUploadUrl() throws IOException {
        String url = CacheUtil.getObject(new CacheObjectParam<String>() {

            @Override
            public String fetchKey() {
                return "$$__getUploadUrl";
            }

            @Override
            public String getDataType() {
                return DataTypeConstants.SYSTEM_CONFIG;
            }

            @Override
            public Long getAgencyId() {
                return 0l;
            }

            @Override
            public String fetchObject() {
                try {
                    String url = HttpAction(formatUrl(null, HttpFileEnum.UPLOAD_URL, null), METHOD_GET,
                            new HttpResult<String>() {
                                @Override
                                public String result(HttpURLConnection conn) throws IOException {
                                    int code = conn.getResponseCode();
                                    if (code >= 400) {
                                        throw new IOException("上传文件接口获取失败，将无法文件上传");
                                    }

                                    return getConnectionText(conn);
                                }
                            });
                    if (!Util.checkUrl(url)) {
                        return null;
                    }
                    return url;
                }
                catch (Exception e) {
                    log.error(e);
                }

                return null;
            }
        });

        if (StringUtils.isBlank(url)) {
            throw new IOException("获取不到storage上传接口地址");
        }
        return url;
    }
}
