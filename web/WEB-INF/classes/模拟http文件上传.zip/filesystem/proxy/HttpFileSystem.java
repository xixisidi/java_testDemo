/* 
 * @(#)HttpFileSystem.java    Created on 2015-4-30
 * Copyright (c) 2015 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package net.zdsoft.netstudy.common.filesystem.proxy;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import net.zdsoft.netstudy.common.enums.HttpFileEnum;
import net.zdsoft.netstudy.common.filesystem.FileSystem;
import net.zdsoft.netstudy.common.filesystem.proxy.http.HttpFile;

/**
 * http访问文件
 * 
 * @author Administrator
 * @version $Revision: 1.0 $, $Date: 2015-4-30 下午4:28:24 $
 */
public class HttpFileSystem implements FileSystem {
    private final Logger log = Logger.getLogger(getClass());
    private static HttpFile httpFile = null;

    /**
     * 初始化
     * 
     * @param storePath
     */
    public HttpFileSystem() {
        httpFile = new HttpFile();
    }

    @Override
    public Boolean saveFile(Object src, String filePath) throws Exception {
        if (src instanceof File) {
            return httpFile.writeFile(filePath, (File) src);
        }
        else if (src instanceof String) {
            return httpFile.writeFile(filePath, (String) src);
        }
        else if (src instanceof InputStream) {
            return httpFile.writeFile(filePath, (InputStream) src);
        }
        else {
            return false;
        }
    }

    @Override
    public Boolean copyFile(String srcPath, String desPath) throws Exception {
        return httpFile.copyFile(srcPath, desPath);
    }

    @Override
    public Boolean copyFileToLocal(String filePath, String localFilePath) throws Exception {
        return httpFile.copyFileToLocal(filePath, localFilePath);
    }

    @Override
    public Boolean deleteFile(String filePath) throws Exception {
        return httpFile.deleteFileOrDir(filePath);
    }

    @Override
    public Boolean deleteDir(String filePath) throws Exception {
        return httpFile.deleteFileOrDir(filePath);
    }

    @Override
    public InputStream getFileAsStream(String filePath) throws Exception {
        return httpFile.getFileAsStream(filePath);
    }

    @Override
    public String getFileAsString(String filePath) throws Exception {
        return httpFile.getFileAsString(filePath);
    }

    @Override
    public String[] getFiles(String dirPath) throws Exception {
        return httpFile.getFileList(dirPath);
    }

    @Override
    public String[] getFilesName(String dirPath) throws Exception {
        String[] list = httpFile.getFileList(dirPath);
        if (ArrayUtils.isEmpty(list)) {
            return null;
        }
        for (int i = 0; i < list.length; i++) {
            list[i] = new File(list[i]).getName();
        }
        return list;
    }

    @Override
    public Boolean fileExists(String filePath) {
        try {
            return httpFile.getFileExist(filePath, HttpFileEnum.FILE_EXIST);
        }
        catch (IOException e) {
            return false;
        }
    }

    @Override
    public Boolean dirExists(String dirPath) {
        try {
            return httpFile.getFileExist(dirPath, HttpFileEnum.FILE_EXIST);
        }
        catch (IOException e) {
            return false;
        }
    }

    @Override
    public Long getFileLength(String filePath) {
        try {
            return httpFile.getFileLength(filePath);
        }
        catch (IOException e) {
            return -1L;
        }
    }

    @Override
    public Date getLastModified(String filePath) throws Exception {
        return httpFile.getFileDate(filePath);
    }

    @Override
    public Boolean mkDir(String filePath) throws Exception {
        return httpFile.makeDir(filePath);
    }

    @Override
    public Boolean cutFile(String srcPath, String destinationPath) {
        try {
            httpFile.moveFile(srcPath, destinationPath);
            httpFile.deleteFileOrDir(srcPath);
            return true;
        }
        catch (IOException e) {
            log.error(e);
            return false;
        }
    }

    @Override
    public Boolean randomWrite(Object data, long begin, String path) throws Exception {
        return null;
    }

    @Override
    public Boolean flushFileCache(String... paths) {
        return null;
    }

}
