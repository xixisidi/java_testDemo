package net.zdsoft.netstudy.common.filesystem.proxy;

import java.io.InputStream;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.fs.LocalFileSystem;

import net.zdsoft.netstudy.common.filesystem.FileSystem;
import net.zdsoft.netstudy.common.utils.NetstudyFileUtils;

/**
 * 文件读写工具类
 * 
 * @author
 * @date 2013-8-17
 * @version V 1.0
 */
public class FileSystemUtilProxy {
    private static FileSystem FILE_SYSTEM = null;
    public static final String TEMP_DIR = "temp/";

    /**
     * 初始化文件服务器
     * 
     * @param system
     */
    public static void setSystem(FileSystem system) {
        if (system == null) {
            throw new RuntimeException("文件服务器为空！");
        }
        FileSystemUtilProxy.FILE_SYSTEM = system;
    }

    /**
     * 删除文件服务器的文件
     * 
     * @param filePath
     * @return
     */
    public static Boolean deleteFile(String path) throws Exception {
        if (StringUtils.isBlank(path)) {
            return false;
        }
        return FILE_SYSTEM.deleteFile(deleteMark(path));
    }

    /**
     * 删除服务器端文件夹
     * 
     * @param path
     * @return
     * @throws Exception
     */
    public static Boolean deleteDir(String path) throws Exception {
        if (StringUtils.isBlank(path)) {
            return false;
        }
        return FILE_SYSTEM.deleteDir(path);
    }

    /**
     * 获取文件服务器的文件流
     * 
     * @param filePath
     * @return
     */
    public static InputStream getFileAsStream(String path) throws Exception {
        return FILE_SYSTEM.getFileAsStream(deleteMark(path));
    }

    /**
     * 读取文件服务器中的文件
     * 
     * @param path
     * @return
     * @throws Exception
     */
    public static String getFileAsString(String path) throws Exception {
        return FILE_SYSTEM.getFileAsString(deleteMark(path));
    }

    /**
     * 保存文件到文件服务器
     * 
     * @param src
     *            支持3种类型(1:File 2:String 3:InputStream)
     * @param filePath
     */
    public static Boolean saveFile(Object src, String path) throws Exception {
        return FILE_SYSTEM.saveFile(src, deleteMark(path));
    }

    /**
     * 将文件从文件服务器拷贝到本地
     * 
     * @return
     * @throws Exception
     */
    public static Boolean copyFileToLocal(String filePath, String localFilePath) throws Exception {
        return FILE_SYSTEM.copyFileToLocal(deleteMark(filePath), deleteMark(localFilePath));
    }

    /**
     * 文件服务器中从一个文件拷贝到另一个文件中
     * 
     * @param srcPath
     * @param destinationPath
     * @return
     * @throws Exception
     */
    public static Boolean copyFile(String srcPath, String destinationPath) throws Exception {
        return FILE_SYSTEM.copyFile(deleteMark(srcPath), deleteMark(destinationPath));
    }

    /**
     * 获取此文件服务器文件夹下的所有文件
     * 
     * @param dirPath
     */
    public static String[] getFiles(String dirPath) throws Exception {
        return FILE_SYSTEM.getFiles(deleteMark(dirPath));
    }

    /**
     * 获取此文件服务器文件夹下的所有文件名
     * 
     * @param dirPath
     * @return
     * @throws Exception
     */
    public static String[] getFilesName(String dirPath) throws Exception {
        return FILE_SYSTEM.getFilesName(deleteMark(dirPath));
    }

    /**
     * 文件服务器文件路径是否存在
     * 
     * @param filePath
     * @return
     */
    public static Boolean fileExists(String filePath) {
        return FILE_SYSTEM.fileExists(deleteMark(filePath));
    }

    /**
     * 判断文件服务器文件夹是否存在
     * 
     * @param dirPath
     * @return
     */
    public static Boolean dirExists(String dirPath) {
        return FILE_SYSTEM.dirExists(deleteMark(dirPath));
    }

    /**
     * 获取文件大小
     * 
     * @param filePath
     * @return
     */
    public static Long getFileLength(String filePath) {
        return FILE_SYSTEM.getFileLength(deleteMark(filePath));
    }

    /**
     * 获取最后修改时间
     * 
     * @param filePath
     * @return
     */
    public static Date getLastModified(String filePath) throws Exception {
        return FILE_SYSTEM.getLastModified(deleteMark(filePath));
    }

    /**
     * 创建文件夹
     * 
     * @param filePath
     * @return
     * @throws Exception
     */
    public static Boolean mkDir(String filePath) throws Exception {
        return FILE_SYSTEM.mkDir(filePath);
    }

    /**
     * 剪切文件到另一个文件
     * 
     * @param srcPath
     * @param destinationPath
     * @return
     */
    public static Boolean cutFile(String srcPath, String destinationPath) {
        return FILE_SYSTEM.cutFile(deleteMark(srcPath), deleteMark(destinationPath));
    }

    /**
     * 对文件内容进行追加和覆盖 --只允许本地文件系统
     * 
     * @param data
     *            数组或流
     * @param begin
     *            写入起始地址
     * @param path
     *            文件路径
     * @return
     * @throws Exception
     */
    public static Boolean randomWrite(Object data, long begin, String path) throws Exception {
        if (!(FILE_SYSTEM instanceof LocalFileSystem)) {
            throw new Exception("该方法只允许LocalFileSystem使用");
        }
        return FILE_SYSTEM.randomWrite(data, begin, path);
    }

    /**
     * 刷新文件缓存 --只允许upyun文件系统使用
     * 
     * @param paths
     * @return
     */
    public static Boolean flushFileCache(String... paths) {
        return FILE_SYSTEM.flushFileCache(paths);
    }

    /**
     * 过滤版本号信息
     * 
     * @param src
     * @return
     */
    private static String deleteMark(String src) {
        return NetstudyFileUtils.deleteMark(src);
    }
}
